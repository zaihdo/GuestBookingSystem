﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Phumla_Kamnandi_30.Business;

namespace Phumla_Kamnandi_30.Presentation
{
    public partial class HotelMDIParent1 : Form
    {
        private int childFormNumber = 0;
        public CreateBookingForm bookingForm;
        public BookingController bookingController;
        public CreateGuestForm guestForm;
        public GuestController guestController;

        public HotelMDIParent1()
        {
            InitializeComponent();
         //   this.WindowState = FormWindowState.Maximized;
            bookingController = new BookingController();
            guestController = new GuestController();

        }

        #region Tool strip menus

        private void ShowNewForm(object sender, EventArgs e)
        {
            Form childForm = new Form();
            childForm.MdiParent = this;
            childForm.Text = "Window " + childFormNumber++;
            childForm.Show();
        }
        private void OpenFile(object sender, EventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog();
            openFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            openFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (openFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = openFileDialog.FileName;
            }
        }

        private void SaveAsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            SaveFileDialog saveFileDialog = new SaveFileDialog();
            saveFileDialog.InitialDirectory = Environment.GetFolderPath(Environment.SpecialFolder.Personal);
            saveFileDialog.Filter = "Text Files (*.txt)|*.txt|All Files (*.*)|*.*";
            if (saveFileDialog.ShowDialog(this) == DialogResult.OK)
            {
                string FileName = saveFileDialog.FileName;
            }
        }

        private void ExitToolsStripMenuItem_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void CutToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void CopyToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void PasteToolStripMenuItem_Click(object sender, EventArgs e)
        {
        }

        private void ToolBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            toolStrip.Visible = toolBarToolStripMenuItem.Checked;
        }

        private void StatusBarToolStripMenuItem_Click(object sender, EventArgs e)
        {
            statusStrip.Visible = statusBarToolStripMenuItem.Checked;
        }

        private void CascadeToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.Cascade);
        }

        private void TileVerticalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileVertical);
        }

        private void TileHorizontalToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.TileHorizontal);
        }

        private void ArrangeIconsToolStripMenuItem_Click(object sender, EventArgs e)
        {
            LayoutMdi(MdiLayout.ArrangeIcons);
        }

        private void CloseAllToolStripMenuItem_Click(object sender, EventArgs e)
        {
            foreach (Form childForm in MdiChildren)
            {
                childForm.Close();
            }
        }

        #endregion
       

        #region Create a New ChildForm  

        private void CreateNewBookingForm()
        {
            bookingForm = new CreateBookingForm(bookingController);
            bookingForm.MdiParent = this;
            bookingForm.StartPosition = FormStartPosition.CenterParent;
            System.Windows.Forms.MessageBox.Show("126");
        }

         public void CreateNewGuestForm()
        {
            guestForm = new CreateGuestForm(guestController, bookingController);
            guestForm.MdiParent = this;
            guestForm.StartPosition = FormStartPosition.CenterParent;
            
            //guestForm.Show();
        }

        #endregion

        #region Booking ToolStrip Items
        private void createBookingToolStripMenuItem_Click(object sender, EventArgs e)
        {
            if (bookingForm == null)
            {
                CreateNewBookingForm();
            }
        }
        #endregion

        

        private void HotelMDIParent1_Load(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void createBookingToolStripMenuItem_Click_1(object sender, EventArgs e)
        {
            if (bookingForm == null)
            {
                CreateNewBookingForm();
                bookingForm.Show();
            }
        }

        private void bookingsToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }
    }
}
