﻿
namespace Phumla_Kamnandi_30.Presentation
{
    partial class txtInfo
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.lblGuestID = new System.Windows.Forms.Label();
            this.lblGuestName = new System.Windows.Forms.Label();
            this.gbxGuest = new System.Windows.Forms.GroupBox();
            this.txtGuestID = new System.Windows.Forms.TextBox();
            this.txtName = new System.Windows.Forms.TextBox();
            this.v = new System.Windows.Forms.Button();
            this.btnCreateNewGuest = new System.Windows.Forms.Button();
            this.richTextBox1 = new System.Windows.Forms.RichTextBox();
            this.gbxBooking = new System.Windows.Forms.GroupBox();
            this.lblCheckIn = new System.Windows.Forms.Label();
            this.lblCheckOut = new System.Windows.Forms.Label();
            this.lblNumRooms = new System.Windows.Forms.Label();
            this.lblRate = new System.Windows.Forms.Label();
            this.txtCheckIn = new System.Windows.Forms.TextBox();
            this.txtCheckOut = new System.Windows.Forms.TextBox();
            this.radLow = new System.Windows.Forms.RadioButton();
            this.radMed = new System.Windows.Forms.RadioButton();
            this.radHigh = new System.Windows.Forms.RadioButton();
            this.txtNumRooms = new System.Windows.Forms.TextBox();
            this.btnSubmitBooking = new System.Windows.Forms.Button();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.btnCancel = new System.Windows.Forms.Button();
            this.gbxGuest.SuspendLayout();
            this.gbxBooking.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // lblGuestID
            // 
            this.lblGuestID.AutoSize = true;
            this.lblGuestID.Location = new System.Drawing.Point(35, 29);
            this.lblGuestID.Name = "lblGuestID";
            this.lblGuestID.Size = new System.Drawing.Size(49, 13);
            this.lblGuestID.TabIndex = 0;
            this.lblGuestID.Text = "Guest ID";
            // 
            // lblGuestName
            // 
            this.lblGuestName.AutoSize = true;
            this.lblGuestName.Location = new System.Drawing.Point(35, 63);
            this.lblGuestName.Name = "lblGuestName";
            this.lblGuestName.Size = new System.Drawing.Size(35, 13);
            this.lblGuestName.TabIndex = 1;
            this.lblGuestName.Text = "Name";
            // 
            // gbxGuest
            // 
            this.gbxGuest.Controls.Add(this.richTextBox1);
            this.gbxGuest.Controls.Add(this.btnCreateNewGuest);
            this.gbxGuest.Controls.Add(this.v);
            this.gbxGuest.Controls.Add(this.txtName);
            this.gbxGuest.Controls.Add(this.txtGuestID);
            this.gbxGuest.Controls.Add(this.lblGuestID);
            this.gbxGuest.Controls.Add(this.lblGuestName);
            this.gbxGuest.Location = new System.Drawing.Point(47, 33);
            this.gbxGuest.Name = "gbxGuest";
            this.gbxGuest.Size = new System.Drawing.Size(427, 160);
            this.gbxGuest.TabIndex = 2;
            this.gbxGuest.TabStop = false;
            this.gbxGuest.Text = "Guest";
            // 
            // txtGuestID
            // 
            this.txtGuestID.Location = new System.Drawing.Point(115, 26);
            this.txtGuestID.Name = "txtGuestID";
            this.txtGuestID.Size = new System.Drawing.Size(154, 20);
            this.txtGuestID.TabIndex = 2;
            // 
            // txtName
            // 
            this.txtName.Location = new System.Drawing.Point(115, 60);
            this.txtName.Name = "txtName";
            this.txtName.ReadOnly = true;
            this.txtName.Size = new System.Drawing.Size(154, 20);
            this.txtName.TabIndex = 3;
            // 
            // v
            // 
            this.v.Location = new System.Drawing.Point(330, 24);
            this.v.Name = "v";
            this.v.Size = new System.Drawing.Size(75, 23);
            this.v.TabIndex = 4;
            this.v.Text = "Submit";
            this.v.UseVisualStyleBackColor = true;
            // 
            // btnCreateNewGuest
            // 
            this.btnCreateNewGuest.Location = new System.Drawing.Point(330, 103);
            this.btnCreateNewGuest.Name = "btnCreateNewGuest";
            this.btnCreateNewGuest.Size = new System.Drawing.Size(75, 35);
            this.btnCreateNewGuest.TabIndex = 5;
            this.btnCreateNewGuest.Text = "Create New Guest";
            this.btnCreateNewGuest.UseVisualStyleBackColor = true;
            // 
            // richTextBox1
            // 
            this.richTextBox1.Location = new System.Drawing.Point(19, 103);
            this.richTextBox1.Name = "richTextBox1";
            this.richTextBox1.ReadOnly = true;
            this.richTextBox1.Size = new System.Drawing.Size(250, 35);
            this.richTextBox1.TabIndex = 6;
            this.richTextBox1.Text = "If the person is a new guest to the hotel or doesn\'t exist in the database, creat" +
    "e them a guest account:";
            // 
            // gbxBooking
            // 
            this.gbxBooking.Controls.Add(this.btnSubmitBooking);
            this.gbxBooking.Controls.Add(this.txtNumRooms);
            this.gbxBooking.Controls.Add(this.radHigh);
            this.gbxBooking.Controls.Add(this.radMed);
            this.gbxBooking.Controls.Add(this.radLow);
            this.gbxBooking.Controls.Add(this.txtCheckIn);
            this.gbxBooking.Controls.Add(this.txtCheckOut);
            this.gbxBooking.Controls.Add(this.lblRate);
            this.gbxBooking.Controls.Add(this.lblNumRooms);
            this.gbxBooking.Controls.Add(this.lblCheckOut);
            this.gbxBooking.Controls.Add(this.lblCheckIn);
            this.gbxBooking.Location = new System.Drawing.Point(47, 220);
            this.gbxBooking.Name = "gbxBooking";
            this.gbxBooking.Size = new System.Drawing.Size(427, 191);
            this.gbxBooking.TabIndex = 3;
            this.gbxBooking.TabStop = false;
            this.gbxBooking.Text = "Booking Details";
            // 
            // lblCheckIn
            // 
            this.lblCheckIn.AutoSize = true;
            this.lblCheckIn.Location = new System.Drawing.Point(16, 38);
            this.lblCheckIn.Name = "lblCheckIn";
            this.lblCheckIn.Size = new System.Drawing.Size(76, 13);
            this.lblCheckIn.TabIndex = 7;
            this.lblCheckIn.Text = "Check-In Date";
            // 
            // lblCheckOut
            // 
            this.lblCheckOut.AutoSize = true;
            this.lblCheckOut.Location = new System.Drawing.Point(16, 73);
            this.lblCheckOut.Name = "lblCheckOut";
            this.lblCheckOut.Size = new System.Drawing.Size(84, 13);
            this.lblCheckOut.TabIndex = 8;
            this.lblCheckOut.Text = "Check-Out Date";
            this.lblCheckOut.Click += new System.EventHandler(this.label2_Click);
            // 
            // lblNumRooms
            // 
            this.lblNumRooms.AutoSize = true;
            this.lblNumRooms.Location = new System.Drawing.Point(16, 107);
            this.lblNumRooms.Name = "lblNumRooms";
            this.lblNumRooms.Size = new System.Drawing.Size(92, 13);
            this.lblNumRooms.TabIndex = 9;
            this.lblNumRooms.Text = "Number of Rooms";
            // 
            // lblRate
            // 
            this.lblRate.AutoSize = true;
            this.lblRate.Location = new System.Drawing.Point(16, 141);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(75, 13);
            this.lblRate.TabIndex = 10;
            this.lblRate.Text = "Rate (Season)";
            // 
            // txtCheckIn
            // 
            this.txtCheckIn.Location = new System.Drawing.Point(144, 35);
            this.txtCheckIn.Name = "txtCheckIn";
            this.txtCheckIn.Size = new System.Drawing.Size(154, 20);
            this.txtCheckIn.TabIndex = 7;
            // 
            // txtCheckOut
            // 
            this.txtCheckOut.Location = new System.Drawing.Point(144, 70);
            this.txtCheckOut.Name = "txtCheckOut";
            this.txtCheckOut.Size = new System.Drawing.Size(154, 20);
            this.txtCheckOut.TabIndex = 8;
            // 
            // radLow
            // 
            this.radLow.AutoSize = true;
            this.radLow.Location = new System.Drawing.Point(144, 139);
            this.radLow.Name = "radLow";
            this.radLow.Size = new System.Drawing.Size(45, 17);
            this.radLow.TabIndex = 11;
            this.radLow.TabStop = true;
            this.radLow.Text = "Low";
            this.radLow.UseVisualStyleBackColor = true;
            // 
            // radMed
            // 
            this.radMed.AutoSize = true;
            this.radMed.Location = new System.Drawing.Point(195, 139);
            this.radMed.Name = "radMed";
            this.radMed.Size = new System.Drawing.Size(62, 17);
            this.radMed.TabIndex = 12;
            this.radMed.TabStop = true;
            this.radMed.Text = "Medium";
            this.radMed.UseVisualStyleBackColor = true;
            // 
            // radHigh
            // 
            this.radHigh.AutoSize = true;
            this.radHigh.Location = new System.Drawing.Point(263, 139);
            this.radHigh.Name = "radHigh";
            this.radHigh.Size = new System.Drawing.Size(47, 17);
            this.radHigh.TabIndex = 13;
            this.radHigh.TabStop = true;
            this.radHigh.Text = "High";
            this.radHigh.UseVisualStyleBackColor = true;
            // 
            // txtNumRooms
            // 
            this.txtNumRooms.Location = new System.Drawing.Point(144, 104);
            this.txtNumRooms.Name = "txtNumRooms";
            this.txtNumRooms.Size = new System.Drawing.Size(154, 20);
            this.txtNumRooms.TabIndex = 14;
            // 
            // btnSubmitBooking
            // 
            this.btnSubmitBooking.Location = new System.Drawing.Point(330, 114);
            this.btnSubmitBooking.Name = "btnSubmitBooking";
            this.btnSubmitBooking.Size = new System.Drawing.Size(75, 40);
            this.btnSubmitBooking.TabIndex = 7;
            this.btnSubmitBooking.Text = "Submit Booking";
            this.btnSubmitBooking.UseVisualStyleBackColor = true;
            // 
            // menuStrip1
            // 
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(510, 24);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(37, 20);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.homeToolStripMenuItem.Text = "Home";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(180, 22);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(377, 433);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(75, 23);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            // 
            // txtInfo
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(510, 481);
            this.Controls.Add(this.btnCancel);
            this.Controls.Add(this.gbxBooking);
            this.Controls.Add(this.gbxGuest);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Name = "txtInfo";
            this.Text = "Create Booking";
            this.gbxGuest.ResumeLayout(false);
            this.gbxGuest.PerformLayout();
            this.gbxBooking.ResumeLayout(false);
            this.gbxBooking.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lblGuestID;
        private System.Windows.Forms.Label lblGuestName;
        private System.Windows.Forms.GroupBox gbxGuest;
        private System.Windows.Forms.RichTextBox richTextBox1;
        private System.Windows.Forms.Button btnCreateNewGuest;
        private System.Windows.Forms.Button v;
        private System.Windows.Forms.TextBox txtName;
        private System.Windows.Forms.TextBox txtGuestID;
        private System.Windows.Forms.GroupBox gbxBooking;
        private System.Windows.Forms.Label lblRate;
        private System.Windows.Forms.Label lblNumRooms;
        private System.Windows.Forms.Label lblCheckOut;
        private System.Windows.Forms.Label lblCheckIn;
        private System.Windows.Forms.Button btnSubmitBooking;
        private System.Windows.Forms.TextBox txtNumRooms;
        private System.Windows.Forms.RadioButton radHigh;
        private System.Windows.Forms.RadioButton radMed;
        private System.Windows.Forms.RadioButton radLow;
        private System.Windows.Forms.TextBox txtCheckIn;
        private System.Windows.Forms.TextBox txtCheckOut;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button btnCancel;
    }
}