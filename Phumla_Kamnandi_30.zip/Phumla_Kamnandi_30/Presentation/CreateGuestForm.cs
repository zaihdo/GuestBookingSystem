﻿using Phumla_Kamnandi_30.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Phumla_Kamnandi_30.Data;

namespace Phumla_Kamnandi_30.Presentation
{
    public partial class CreateGuestForm : Form
    {
        private Guest guest;
        private Booking booking;
        private BookingController bookingController;
        private GuestController guestController;
        public bool guestFormClosed = false;
        
        public CreateGuestForm(GuestController aContoller)
        {
            InitializeComponent();
            guestController = aContoller;
        }

        public CreateGuestForm(BookingController aController)
        {
            InitializeComponent();
            bookingController = aController;
        }

        public CreateGuestForm(GuestController aController, BookingController AController)
        {
            System.Windows.Forms.MessageBox.Show("I'm working");
            InitializeComponent();
            guestController = aController;
            bookingController = AController;
        }

        #region Utility Methods

        private void ClearAll()
        {
            txtName.Text = "";
            txtID.Text = "";
            txtEmail.Text = "";
            txtPhone.Text = "";
            txtResAddress.Text = "";
        }

        private void PopulateObject()
        {
            guest = new Guest();
            //  booking.getBookingID = idTextBox.Text;
            guest.getGuestID = GuestIDtxt.Text;
            guest.getName = txtName.Text;
            guest.getID = txtID.Text;
            guest.getPhone = txtPhone.Text;
            guest.getEmail = txtEmail.Text;
            guest.getAddress = txtResAddress.Text;

            CreateBookingForm bookingForm = new CreateBookingForm(bookingController);
            booking = new Booking();
            booking.getBookingID = bookingForm.bookingID;
            booking.getGuestID = GuestIDtxt.Text;
            booking.getCheckIn = bookingForm.checkIn;
            booking.getCheckOut = bookingForm.checkOut;
            booking.getNumRooms = bookingForm.numRooms;
            booking.getTotalCharge = bookingForm.totalPrice;
        }
        #endregion

        #region labels and controls
        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtResAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void CreateGuestForm_Load(object sender, EventArgs e)
        {

        }

        #endregion

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void btnCancel_Click(object sender, EventArgs e)
        {
            ClearAll();
        }

        private void btnClear_Click(object sender, EventArgs e)
        {
            guestFormClosed = true;
            Close();
        }

        private void btnSubmit_Click(object sender, EventArgs e)
        {
            PopulateObject();
            guestController.DataMaintenance(guest, DB.DBOperation.Add);
            guestController.FinalizeChanges(guest);
            bookingController.DataMaintenance(booking, DB.DBOperation.Add);
            bookingController.FinalizeChanges(booking);
            ClearAll();
        }
    }
}
