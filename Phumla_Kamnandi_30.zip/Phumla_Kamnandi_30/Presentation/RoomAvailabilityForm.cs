﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using Phumla_Kamnandi_30.Business;

namespace Phumla_Kamnandi_30.Presentation
{
    public partial class RoomAvailabilityForm : Form
    {
        #region Data Members


        #endregion

        #region constructor
        public RoomAvailabilityForm()
        {
            InitializeComponent();
        }
        #endregion

        private void btnSubmitRmAvail_Click(object sender, EventArgs e)
        {

        }

        #region utility methods
        public int numAvailableRooms()
        {
            int numRoomsAvailable = 0;
            // functionality required

            return numRoomsAvailable;
        }

        #endregion
    }
}
