﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Phumla_Kamnandi_30.Business
{
    public class Guest:Person
    {
        #region Data Members
        private string guestID;
        private string email;
       
        #endregion

        #region properties
        public string getGuestID
        {
            get { return guestID;  }
            set { guestID = value; }
        }

        public string getEmail
        {
            get { return email; }
            set { email = value; }
        }
        #endregion

        #region Constructor
        public Guest() 
        {
            guestID = "";

        }
        #endregion

    }
}
