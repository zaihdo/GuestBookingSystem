﻿using Phumla_Kamnandi_30.Business;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace Phumla_Kamnandi_30.Presentation
{
    public partial class CreateGuestForm : Form
    {
        private Guest guest;
        private GuestController guestController;
        public bool guestFormClosed = false;
        
        public CreateGuestForm(GuestController aContoller)
        {
            InitializeComponent();
            guestController = aContoller;
        }

        #region Utility Methods

        private void ClearAll()
        {
            txtName.Text = "";
            txtID.Text = "";
            txtEmail.Text = "";
            txtPhone.Text = "";
            txtResAddress.Text = "";
        }

        private void PopulateObject()
        {
            guest = new Guest();
            //  booking.getBookingID = idTextBox.Text;
            guest.getName = txtName.Text;
            guest.getID = txtID.Text;
            guest.getPhone = txtPhone.Text;
            guest.getEmail = txtEmail.Text;
            guest.getAddress = txtResAddress.Text;
        }
        #endregion

        #region labels and controls
        private void txtName_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtID_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtPhone_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtEmail_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtResAddress_TextChanged(object sender, EventArgs e)
        {

        }

        private void CreateGuestForm_Load(object sender, EventArgs e)
        {

        }

        #endregion
    }
}
