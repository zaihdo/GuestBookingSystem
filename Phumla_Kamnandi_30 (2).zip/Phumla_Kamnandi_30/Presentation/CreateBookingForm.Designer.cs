﻿
namespace Phumla_Kamnandi_30.Presentation
{
    partial class CreateBookingForm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.gbxBooking = new System.Windows.Forms.GroupBox();
            this.exitButton = new System.Windows.Forms.Button();
            this.numRoomsCombo = new System.Windows.Forms.ComboBox();
            this.checkOutPicker = new System.Windows.Forms.DateTimePicker();
            this.checkInPicker = new System.Windows.Forms.DateTimePicker();
            this.btnCancel = new System.Windows.Forms.Button();
            this.btnSubmitBooking = new System.Windows.Forms.Button();
            this.radHigh = new System.Windows.Forms.RadioButton();
            this.radMed = new System.Windows.Forms.RadioButton();
            this.radLow = new System.Windows.Forms.RadioButton();
            this.lblRate = new System.Windows.Forms.Label();
            this.lblNumRooms = new System.Windows.Forms.Label();
            this.lblCheckOut = new System.Windows.Forms.Label();
            this.lblCheckIn = new System.Windows.Forms.Label();
            this.menuStrip1 = new System.Windows.Forms.MenuStrip();
            this.fileToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.homeToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.exitToolStripMenuItem = new System.Windows.Forms.ToolStripMenuItem();
            this.gbxBooking.SuspendLayout();
            this.menuStrip1.SuspendLayout();
            this.SuspendLayout();
            // 
            // gbxBooking
            // 
            this.gbxBooking.Controls.Add(this.exitButton);
            this.gbxBooking.Controls.Add(this.numRoomsCombo);
            this.gbxBooking.Controls.Add(this.checkOutPicker);
            this.gbxBooking.Controls.Add(this.checkInPicker);
            this.gbxBooking.Controls.Add(this.btnCancel);
            this.gbxBooking.Controls.Add(this.btnSubmitBooking);
            this.gbxBooking.Controls.Add(this.radHigh);
            this.gbxBooking.Controls.Add(this.radMed);
            this.gbxBooking.Controls.Add(this.radLow);
            this.gbxBooking.Controls.Add(this.lblRate);
            this.gbxBooking.Controls.Add(this.lblNumRooms);
            this.gbxBooking.Controls.Add(this.lblCheckOut);
            this.gbxBooking.Controls.Add(this.lblCheckIn);
            this.gbxBooking.Location = new System.Drawing.Point(33, 46);
            this.gbxBooking.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxBooking.Name = "gbxBooking";
            this.gbxBooking.Padding = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.gbxBooking.Size = new System.Drawing.Size(569, 235);
            this.gbxBooking.TabIndex = 3;
            this.gbxBooking.TabStop = false;
            this.gbxBooking.Text = "Booking Details";
            // 
            // exitButton
            // 
            this.exitButton.Location = new System.Drawing.Point(461, 199);
            this.exitButton.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.exitButton.Name = "exitButton";
            this.exitButton.Size = new System.Drawing.Size(100, 28);
            this.exitButton.TabIndex = 8;
            this.exitButton.Text = "Exit";
            this.exitButton.UseVisualStyleBackColor = true;
            this.exitButton.Click += new System.EventHandler(this.exitButton_Click_1);
            // 
            // numRoomsCombo
            // 
            this.numRoomsCombo.FormattingEnabled = true;
            this.numRoomsCombo.Location = new System.Drawing.Point(163, 128);
            this.numRoomsCombo.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.numRoomsCombo.Name = "numRoomsCombo";
            this.numRoomsCombo.Size = new System.Drawing.Size(160, 24);
            this.numRoomsCombo.TabIndex = 17;
            // 
            // checkOutPicker
            // 
            this.checkOutPicker.Location = new System.Drawing.Point(163, 90);
            this.checkOutPicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkOutPicker.Name = "checkOutPicker";
            this.checkOutPicker.Size = new System.Drawing.Size(265, 22);
            this.checkOutPicker.TabIndex = 15;
            // 
            // checkInPicker
            // 
            this.checkInPicker.Location = new System.Drawing.Point(163, 47);
            this.checkInPicker.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.checkInPicker.Name = "checkInPicker";
            this.checkInPicker.Size = new System.Drawing.Size(265, 22);
            this.checkInPicker.TabIndex = 5;
            // 
            // btnCancel
            // 
            this.btnCancel.Location = new System.Drawing.Point(461, 164);
            this.btnCancel.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnCancel.Name = "btnCancel";
            this.btnCancel.Size = new System.Drawing.Size(100, 28);
            this.btnCancel.TabIndex = 7;
            this.btnCancel.Text = "Cancel";
            this.btnCancel.UseVisualStyleBackColor = true;
            this.btnCancel.Click += new System.EventHandler(this.btnCancel_Click_1);
            // 
            // btnSubmitBooking
            // 
            this.btnSubmitBooking.Location = new System.Drawing.Point(461, 105);
            this.btnSubmitBooking.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.btnSubmitBooking.Name = "btnSubmitBooking";
            this.btnSubmitBooking.Size = new System.Drawing.Size(100, 49);
            this.btnSubmitBooking.TabIndex = 7;
            this.btnSubmitBooking.Text = "Submit Booking";
            this.btnSubmitBooking.UseVisualStyleBackColor = true;
            this.btnSubmitBooking.Click += new System.EventHandler(this.btnSubmitBooking_Click_1);
            // 
            // radHigh
            // 
            this.radHigh.AutoSize = true;
            this.radHigh.Location = new System.Drawing.Point(351, 171);
            this.radHigh.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radHigh.Name = "radHigh";
            this.radHigh.Size = new System.Drawing.Size(58, 21);
            this.radHigh.TabIndex = 13;
            this.radHigh.TabStop = true;
            this.radHigh.Text = "High";
            this.radHigh.UseVisualStyleBackColor = true;
            // 
            // radMed
            // 
            this.radMed.AutoSize = true;
            this.radMed.Location = new System.Drawing.Point(260, 171);
            this.radMed.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radMed.Name = "radMed";
            this.radMed.Size = new System.Drawing.Size(78, 21);
            this.radMed.TabIndex = 12;
            this.radMed.TabStop = true;
            this.radMed.Text = "Medium";
            this.radMed.UseVisualStyleBackColor = true;
            // 
            // radLow
            // 
            this.radLow.AutoSize = true;
            this.radLow.Location = new System.Drawing.Point(192, 171);
            this.radLow.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.radLow.Name = "radLow";
            this.radLow.Size = new System.Drawing.Size(54, 21);
            this.radLow.TabIndex = 11;
            this.radLow.TabStop = true;
            this.radLow.Text = "Low";
            this.radLow.UseVisualStyleBackColor = true;
            // 
            // lblRate
            // 
            this.lblRate.AutoSize = true;
            this.lblRate.Location = new System.Drawing.Point(21, 174);
            this.lblRate.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblRate.Name = "lblRate";
            this.lblRate.Size = new System.Drawing.Size(100, 17);
            this.lblRate.TabIndex = 10;
            this.lblRate.Text = "Rate (Season)";
            // 
            // lblNumRooms
            // 
            this.lblNumRooms.AutoSize = true;
            this.lblNumRooms.Location = new System.Drawing.Point(21, 132);
            this.lblNumRooms.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblNumRooms.Name = "lblNumRooms";
            this.lblNumRooms.Size = new System.Drawing.Size(122, 17);
            this.lblNumRooms.TabIndex = 9;
            this.lblNumRooms.Text = "Number of Rooms";
            // 
            // lblCheckOut
            // 
            this.lblCheckOut.AutoSize = true;
            this.lblCheckOut.Location = new System.Drawing.Point(21, 90);
            this.lblCheckOut.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCheckOut.Name = "lblCheckOut";
            this.lblCheckOut.Size = new System.Drawing.Size(109, 17);
            this.lblCheckOut.TabIndex = 8;
            this.lblCheckOut.Text = "Check-Out Date";
            // 
            // lblCheckIn
            // 
            this.lblCheckIn.AutoSize = true;
            this.lblCheckIn.Location = new System.Drawing.Point(21, 47);
            this.lblCheckIn.Margin = new System.Windows.Forms.Padding(4, 0, 4, 0);
            this.lblCheckIn.Name = "lblCheckIn";
            this.lblCheckIn.Size = new System.Drawing.Size(97, 17);
            this.lblCheckIn.TabIndex = 7;
            this.lblCheckIn.Text = "Check-In Date";
            // 
            // menuStrip1
            // 
            this.menuStrip1.ImageScalingSize = new System.Drawing.Size(20, 20);
            this.menuStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.fileToolStripMenuItem});
            this.menuStrip1.Location = new System.Drawing.Point(0, 0);
            this.menuStrip1.Name = "menuStrip1";
            this.menuStrip1.Size = new System.Drawing.Size(680, 28);
            this.menuStrip1.TabIndex = 4;
            this.menuStrip1.Text = "menuStrip1";
            // 
            // fileToolStripMenuItem
            // 
            this.fileToolStripMenuItem.DropDownItems.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.homeToolStripMenuItem,
            this.exitToolStripMenuItem});
            this.fileToolStripMenuItem.Name = "fileToolStripMenuItem";
            this.fileToolStripMenuItem.Size = new System.Drawing.Size(46, 24);
            this.fileToolStripMenuItem.Text = "File";
            // 
            // homeToolStripMenuItem
            // 
            this.homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            this.homeToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.homeToolStripMenuItem.Text = "Home";
            // 
            // exitToolStripMenuItem
            // 
            this.exitToolStripMenuItem.Name = "exitToolStripMenuItem";
            this.exitToolStripMenuItem.Size = new System.Drawing.Size(133, 26);
            this.exitToolStripMenuItem.Text = "Exit";
            // 
            // CreateBookingForm
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(8F, 16F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(680, 592);
            this.Controls.Add(this.gbxBooking);
            this.Controls.Add(this.menuStrip1);
            this.MainMenuStrip = this.menuStrip1;
            this.Margin = new System.Windows.Forms.Padding(4, 4, 4, 4);
            this.Name = "CreateBookingForm";
            this.Text = "Create Booking";
            this.Load += new System.EventHandler(this.CreateBookingForm_Load);
            this.gbxBooking.ResumeLayout(false);
            this.gbxBooking.PerformLayout();
            this.menuStrip1.ResumeLayout(false);
            this.menuStrip1.PerformLayout();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.GroupBox gbxBooking;
        private System.Windows.Forms.Label lblRate;
        private System.Windows.Forms.Label lblNumRooms;
        private System.Windows.Forms.Label lblCheckOut;
        private System.Windows.Forms.Label lblCheckIn;
        private System.Windows.Forms.Button btnSubmitBooking;
        private System.Windows.Forms.RadioButton radHigh;
        private System.Windows.Forms.RadioButton radMed;
        private System.Windows.Forms.RadioButton radLow;
        private System.Windows.Forms.MenuStrip menuStrip1;
        private System.Windows.Forms.ToolStripMenuItem fileToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem homeToolStripMenuItem;
        private System.Windows.Forms.ToolStripMenuItem exitToolStripMenuItem;
        private System.Windows.Forms.Button btnCancel;
        private System.Windows.Forms.DateTimePicker checkOutPicker;
        private System.Windows.Forms.DateTimePicker checkInPicker;
        private System.Windows.Forms.ComboBox numRoomsCombo;
        private System.Windows.Forms.Button exitButton;
    }
}